from tkinter import messagebox
import tkinter as tk
import random


#\n
class Application(tk.Frame):
    def __init__(self,master):
        super().__init__(master)
        self.pack()

        self.master.geometry("300x160")

        #self.master.wm_attributes('-fullscreen', 'true')
        self.master.title("vocabulary")
        self.master.configure(bg="gray26")
        self.frame()

    def frame(self):
        self.fr = tk.Frame(self.master,bg="gray27",width=300)
        self.fr.pack(fill="x")

        self.entry1 = tk.Entry(self.fr,width=27,bg="gray40")
        self.entry1.pack(fill="x",side = tk.LEFT)



        # button1 = ttk .Button(frame1, text='OK', command=word)
        # shift+return でボタンを押す
        def word(event):
            words = self.entry1.get()
            if words =="":
                messagebox.showerror("Put the word!","ERROR! Put the word!")
            else:
                 #空欄だとエラーを返したい
                print("Button pushed! Got the word: ",words)
                messagebox.showinfo("Confirmation","Copyed!: "+self.entry1.get())
                with open("words.txt", mode='a') as f:
                    f.writelines("\n"+words)
                    f.close()
                self.entry1.delete(0, 'end')


        self.input_label = tk.Label(self.fr, text='INPUT',background="gray30",fg="orange",width=5,borderwidth = 2,
                         relief="raised",)
        self.input_label.pack(fill="x",side ="left")
        self.input_label.bind("<Button-1>", word)

        self.fr2 = tk.Frame(self.master, bg="gray30",width=300)
        self.fr2.pack(fill="x")

        self.fr3 = tk.Frame(self.master, bg="gray25", )
        self.fr3.pack(fill="x")

        self.text = tk.StringVar()
        self.text.set('Push "Repeat" !')
        self.label2 = tk.Label(self.fr2, textvariable=self.text, bg="gray20",fg="snow3",height=3, font=("Helvetica", 30, ""))
        self.label2.pack(fill="x")

        def repeat(event):
            # random words pick
            length = len(open("words.txt").readlines())  # length of text column
            print("length of text column: " + str(length))
            # make random from the length
            random_num = random.randint(0, length-1) #テキストの読み込みは１から、ランダムは０からなのでマイナス１する
            print("picked num"+str(random_num))
            with open("words.txt") as f:
                l = f.readlines()
                rp_word = l[random_num]
                print(str(rp_word)+":")  # print the words at random
                print(str(rp_word.rstrip())+":")
                rp_word=rp_word.rstrip()#なぜか空白の改行が入るので一行に成形
                f.close()
                self.text.set(rp_word)
        def see_all(event):
            '''モードレスダイアログボックスの作成'''
            dlg_modeless = tk.Toplevel(self)
            dlg_modeless.title("You learned ↓")  # ウィンドウタイトル
            #dlg_modeless.geometry("200x400")  # ウィンドウサイズ(幅x高さ)
            dlg_modeless.configure(bg='gray27')
            with open('words.txt') as f:
                s = f.read()
                #print(s)
                #messagebox.showinfo("Confirmation", "You Learned:\n "+ str(s))
                f.close()
            lists = tk.StringVar(value=s)
            Listbox = tk.Listbox(dlg_modeless, listvariable=lists,width=30,height=25,bg="gray27",fg="snow3",font=("Helvetica", 14, "bold"))
            scrollbar = tk.Scrollbar(dlg_modeless, orient=tk.VERTICAL, command=Listbox.yview)
            # スクロールバーをListboxに反映
            Listbox["yscrollcommand"] = scrollbar.set
            Listbox.grid(row=0, column=0)
            scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))


        #def settingaaa(event):
            #print("settings")
            #messagebox.showinfo("Confirmation", "How can I see the txt?\n"
                                               # "⇨Show packages>contents>words.txt")

        def setting(event):
            '''モードレスダイアログボックスの作成'''
            dlg_modeless = tk.Toplevel(self)
            dlg_modeless.title("Modeless Dialog")  # ウィンドウタイトル
            dlg_modeless.geometry("300x300")  # ウィンドウサイズ(幅x高さ)
            fr = tk.Frame(dlg_modeless,bg="gray25",)
            fr.pack()
            label = tk.Label(fr,text="Check my website and access \n 'APPS' to explore more information. \n\n https://haruyama418.github.io/HP/ ",
                             bg="gray25",fg="snow3",width=40,height=30,font=("Helvetica", 14, "bold"))
            label.pack(fill="x")


        self.button1 = tk.Label(self.fr3, text='Repeat', bg="gray30",fg="snow3",width=6,borderwidth = 1,relief="raised",)
        self.button1.pack(padx=20,side="left")
        self.button1.bind("<Button-1>", repeat)
        self.button2 = tk.Label(self.fr3, text='See All', bg="gray30",fg="snow3",width=6,borderwidth = 1,relief="raised")
        self.button2.pack(padx=20,side="left")
        self.button2.bind("<Button-1>", see_all)
        self.button3 = tk.Label(self.fr3, text='Setting', bg="gray30",fg="snow3",width=6,borderwidth = 1,relief="raised")
        self.button3.pack(padx=20,side="left")
        self.button3.bind("<Button-1>", setting)




def main():
    win = tk.Tk()
    app = Application(master=win)
    app.mainloop()


if __name__ == "__main__":
    main()

